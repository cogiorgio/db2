package exceptions;

public class UpdateProfileException extends Throwable{

	public UpdateProfileException(String string) {
		// TODO Auto-generated constructor stub
	}

}
