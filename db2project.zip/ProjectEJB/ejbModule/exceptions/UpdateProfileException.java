package exceptions;

public class UpdateProfileException extends Exception{
	private static final long serialVersionUID = 1L;


	public UpdateProfileException(String message) {
		super(message);
	}

}
