package exceptions;

public class CredentialsException extends Throwable {

	public CredentialsException(String string) {
		// TODO Auto-generated constructor stub
	}

}
