package service;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class QuestionnaireService
 */
@Stateless
@LocalBean
public class QuestionnaireService {

    /**
     * Default constructor. 
     */
    public QuestionnaireService() {
        // TODO Auto-generated constructor stub
    }

}
