package service;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class ReviewService
 */
@Stateless
@LocalBean
public class ReviewService {

    /**
     * Default constructor. 
     */
    public ReviewService() {
        // TODO Auto-generated constructor stub
    }

}
